function Skills({ skills }) {
  return (
    <div>
      <h1>Skills:</h1>
      {skills.map((ele, index) => {
        return <p key={index}>{ele}</p>;
      })}
    </div>
  );
}

export { Skills };
