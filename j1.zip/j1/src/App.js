import "./App.css";
import { Skills } from "./component/Skills";

function App() {
  const data = {
    name: "Akash",
    age: 10,
    skills: ["sex", "alsosex", "coding"],
  };

  return (
    <div className="App">
      <h1>Resume</h1>
      <Intro name={data.name} age={data.age}></Intro>
      <Skills skills={data.skills}></Skills>
    </div>
  );
}

function Intro({ name, age }) {
  return (
    <div>
      <h1>Introdictsoaiu</h1>
      <p>Name: {name}</p>
      <p>Age: {age}</p>
    </div>
  );
}

export default App;
